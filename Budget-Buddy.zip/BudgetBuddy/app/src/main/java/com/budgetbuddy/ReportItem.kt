package com.budgetbuddy

data class ReportItem(
    val categoryName: String,
    val totalAmount: Double
)
